#Autors: Artis Erglis
#Darba merkis: Izvada 11 skaitlus robezhas no 0 lidz 10 un to kvadraatus
print "<HTML>"
for x in range (0, 11):
    print "%-20d %10d </br>" % (x, x**2)
print "</HTML>" 

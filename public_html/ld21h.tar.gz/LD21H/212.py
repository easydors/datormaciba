#Fails: 212.py
#Autors: Artis Erglis
#Aplieciibas numurs: 141REB143
#Darba meerkis: Skaitllu kvadraati utt.

print "<HTML>"
print "<pre>"
for i in range (11):
    k=i*i;
    print "<font color=\"#%s%s00\">" % (i, k)
    print "\tNumber: %s \tSquare: %s" % (i, k)
    print "</font>"

print "</pre>"
print "</HTML>"
